import { i as __toESM } from "../_runtime.mjs";
import { a as AlertDialogDescription, c as AlertDialogTitle, d as DialogOverlay, f as DialogPortal, g as require_react, h as require_jsx_runtime, i as AlertDialogContent, l as Dialog, n as AlertDialogAction, o as AlertDialogOverlay, p as DialogTitle, r as AlertDialogCancel, s as AlertDialogPortal, t as AlertDialog, u as DialogContent } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as ChevronsRight, c as ChevronRight, d as Bell, i as Plus, l as ChevronLeft, o as ChevronsLeft, r as ScrollText, s as ChevronUp, t as X, u as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ZPN0oQGe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ROWS = [
	"LLLLLLLL",
	"LLLLLLLL",
	"LLLSSLLL",
	"LLLSSLLL",
	"LLLLLLLL",
	"LLLLLLLL"
];
function isLand(x, y) {
	if (x < 0 || y < 0 || x >= 8 || y >= 6) return false;
	return ROWS[y][x] === "L";
}
function landCells() {
	const cells = [];
	for (let y = 0; y < 6; y += 1) for (let x = 0; x < 8; x += 1) if (isLand(x, y)) cells.push({
		x,
		y
	});
	return cells;
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/** Server-only. The service role never reaches the browser. */
var getCloudStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("2e4e2e783bb246870e6097d089aae873244479144435124771cdcd69f7a7d623"));
var COUNTRIES = [
	{
		iso: "br",
		name: "Brazil"
	},
	{
		iso: "jp",
		name: "Japan"
	},
	{
		iso: "fr",
		name: "France"
	},
	{
		iso: "mx",
		name: "Mexico"
	},
	{
		iso: "us",
		name: "United States"
	},
	{
		iso: "gb",
		name: "United Kingdom"
	},
	{
		iso: "de",
		name: "Germany"
	},
	{
		iso: "it",
		name: "Italy"
	},
	{
		iso: "es",
		name: "Spain"
	},
	{
		iso: "pt",
		name: "Portugal"
	},
	{
		iso: "cn",
		name: "China"
	},
	{
		iso: "in",
		name: "India"
	},
	{
		iso: "ru",
		name: "Russia"
	},
	{
		iso: "ca",
		name: "Canada"
	},
	{
		iso: "au",
		name: "Australia"
	},
	{
		iso: "kr",
		name: "South Korea"
	},
	{
		iso: "za",
		name: "South Africa"
	},
	{
		iso: "eg",
		name: "Egypt"
	},
	{
		iso: "tr",
		name: "Turkey"
	},
	{
		iso: "sa",
		name: "Saudi Arabia"
	},
	{
		iso: "ar",
		name: "Argentina"
	},
	{
		iso: "se",
		name: "Sweden"
	},
	{
		iso: "no",
		name: "Norway"
	},
	{
		iso: "pl",
		name: "Poland"
	},
	{
		iso: "nl",
		name: "Netherlands"
	},
	{
		iso: "gr",
		name: "Greece"
	},
	{
		iso: "ua",
		name: "Ukraine"
	},
	{
		iso: "id",
		name: "Indonesia"
	},
	{
		iso: "th",
		name: "Thailand"
	},
	{
		iso: "vn",
		name: "Vietnam"
	},
	{
		iso: "ng",
		name: "Nigeria"
	},
	{
		iso: "ke",
		name: "Kenya"
	},
	{
		iso: "nz",
		name: "New Zealand"
	},
	{
		iso: "ch",
		name: "Switzerland"
	},
	{
		iso: "at",
		name: "Austria"
	},
	{
		iso: "ie",
		name: "Ireland"
	},
	{
		iso: "fi",
		name: "Finland"
	},
	{
		iso: "dk",
		name: "Denmark"
	},
	{
		iso: "be",
		name: "Belgium"
	},
	{
		iso: "cl",
		name: "Chile"
	},
	{
		iso: "co",
		name: "Colombia"
	},
	{
		iso: "pe",
		name: "Peru"
	}
];
var byIso = new Map(COUNTRIES.map((c) => [c.iso, c]));
function countryByIso(iso) {
	return byIso.get(iso);
}
var DRILL = [
	{
		name: "Ash Vale",
		iso: "br"
	},
	{
		name: "Kenji Mori",
		iso: "jp"
	},
	{
		name: "Claire Duval",
		iso: "fr"
	},
	{
		name: "Mateo Ruiz",
		iso: "mx"
	}
];
var DRILL_CELLS = [
	{
		x: 1,
		y: 1
	},
	{
		x: 2,
		y: 1
	},
	{
		x: 5,
		y: 4
	},
	{
		x: 6,
		y: 4
	}
];
function chebyshev(ax, ay, bx, by) {
	return Math.max(Math.abs(ax - bx), Math.abs(ay - by));
}
function isOrthogonalStep(ax, ay, bx, by) {
	return Math.abs(ax - bx) + Math.abs(ay - by) === 1;
}
function directionName(dx, dy) {
	if (dx === 0 && dy < 0) return "north";
	if (dx === 0 && dy > 0) return "south";
	if (dx < 0 && dy === 0) return "west";
	if (dx > 0 && dy === 0) return "east";
	return "aside";
}
function nationLabel(nation) {
	return `${nation.name} of ${nation.country}`;
}
function victoryLine(game) {
	if (!game.finishedAt) return null;
	const winner = game.nations.find((n) => n.id === game.winnerId);
	if (!winner) return "The world is unclaimed.";
	return `${nationLabel(winner)} rules the world!`;
}
function chronicleOf(game) {
	return game.plies.flatMap((ply) => ply.chronicle ? [ply.chronicle] : []);
}
function living(nations) {
	return nations.filter((n) => n.alive);
}
function fail(toast) {
	return {
		ok: false,
		toast
	};
}
function snapshotPly(game, text, chronicle) {
	game.plies.push({
		n: game.plies.length,
		text,
		chronicle,
		hour: game.hour,
		snapshot: structuredClone(game.nations)
	});
}
function closeIfAlone(game, now) {
	const left = living(game.nations);
	if (left.length > 1) return false;
	game.finishedAt = now;
	game.winnerId = left[0]?.id ?? null;
	return true;
}
function pickSpawns(count, rng = Math.random) {
	const land = landCells();
	if (count > land.length) throw new Error("Too many nations for this map.");
	const picks = [land[Math.floor(rng() * land.length)]];
	while (picks.length < count) {
		let best = land[0];
		let bestScore = Number.POSITIVE_INFINITY;
		for (const cell of land) {
			if (picks.some((p) => p.x === cell.x && p.y === cell.y)) continue;
			let nearest = Number.POSITIVE_INFINITY;
			for (const picked of picks) nearest = Math.min(nearest, chebyshev(picked.x, picked.y, cell.x, cell.y));
			const score = Math.abs(nearest - 2) + rng() * .15;
			if (score < bestScore) {
				bestScore = score;
				best = cell;
			}
		}
		picks.push(best);
	}
	return picks;
}
function createGame(opts) {
	const now = opts.now ?? Date.now();
	const cells = opts.cells ?? pickSpawns(opts.seats.length, opts.rng ?? Math.random);
	const nations = opts.seats.map((seat, index) => {
		const country = countryByIso(seat.iso);
		const cell = cells[index];
		if (!country || !cell || !isLand(cell.x, cell.y)) throw new Error("A nation could not be seated.");
		return {
			id: `n${index + 1}`,
			name: seat.name.trim(),
			country: country.name,
			iso: country.iso,
			x: cell.x,
			y: cell.y,
			hp: 3,
			ap: 3,
			reach: 1,
			alive: true,
			eliminatedBy: null
		};
	});
	const game = {
		id: opts.id ?? `g-${now.toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`,
		title: opts.title.trim() || "Table",
		createdAt: now,
		finishedAt: null,
		winnerId: null,
		hour: 1,
		nations,
		plies: []
	};
	snapshotPly(game, "The nations take their places.", null);
	return game;
}
function actor(game, id) {
	if (game.finishedAt) return fail("This table has already ended.");
	const nation = game.nations.find((n) => n.id === id);
	if (!nation?.alive) return fail("That nation has already fallen.");
	return nation;
}
function applyAction(game, action, now = Date.now()) {
	const next = structuredClone(game);
	if (action.type === "bell") {
		if (next.finishedAt) return fail("This table has already ended.");
		next.hour += 1;
		for (const nation of next.nations) if (nation.alive) nation.ap = Math.min(8, nation.ap + 2);
		snapshotPly(next, `The bell sounds. Hour ${next.hour}. Living nations gain 2 AP.`, null);
		return {
			ok: true,
			game: next,
			toast: "The hour advances.",
			victory: false
		};
	}
	const found = actor(next, action.id);
	if (!("iso" in found)) return found;
	const self = found;
	if (action.type === "march") {
		if (self.ap < 1) return fail(`You need 1 AP to march.`);
		if (!isLand(action.x, action.y)) return fail("The sea is closed.");
		if (!isOrthogonalStep(self.x, self.y, action.x, action.y)) return fail("That square is not beside you.");
		const occupied = next.nations.find((n) => n.x === action.x && n.y === action.y);
		if (occupied?.alive) return fail("That square is occupied.");
		if (occupied) return fail("A gravestone holds that square.");
		const dir = directionName(action.x - self.x, action.y - self.y);
		self.x = action.x;
		self.y = action.y;
		self.ap -= 1;
		snapshotPly(next, `${nationLabel(self)} marches ${dir}.`, null);
		return {
			ok: true,
			game: next,
			toast: null,
			victory: false
		};
	}
	if (action.type === "extend") {
		if (self.reach >= 3) return fail("Reach cannot extend further.");
		if (self.ap < 2) return fail(`You need 2 AP to extend your reach.`);
		self.ap -= 2;
		self.reach += 1;
		snapshotPly(next, `${nationLabel(self)} extends reach to ${self.reach}.`, null);
		return {
			ok: true,
			game: next,
			toast: `Reach is now ${self.reach}.`,
			victory: false
		};
	}
	if (action.type === "strike") {
		if (self.ap < 1) return fail(`You need 1 AP to strike.`);
		const target = next.nations.find((n) => n.id === action.targetId);
		if (!target || target.id === self.id) return fail("Choose another nation.");
		if (!target.alive) return fail("That nation has already fallen.");
		if (chebyshev(self.x, self.y, target.x, target.y) > self.reach) return fail("They are outside your reach.");
		self.ap -= 1;
		target.hp -= 1;
		if (target.hp > 0) {
			snapshotPly(next, `${nationLabel(self)} strikes ${nationLabel(target)}. Health ${target.hp}.`, null);
			return {
				ok: true,
				game: next,
				toast: "Strike landed.",
				victory: false
			};
		}
		target.hp = 0;
		target.alive = false;
		target.eliminatedBy = self.id;
		const line = `${nationLabel(target)} is eliminated by ${nationLabel(self)}.`;
		snapshotPly(next, line, line);
		const victory = closeIfAlone(next, now);
		return {
			ok: true,
			game: next,
			toast: victory ? null : `${nationLabel(target)} is eliminated.`,
			victory
		};
	}
	if (action.type === "send") {
		if (self.ap < 1) return fail(`You need 1 AP to send.`);
		const target = next.nations.find((n) => n.id === action.targetId);
		if (!target || target.id === self.id) return fail("Choose another nation.");
		if (!target.alive) return fail("That nation has already fallen.");
		if (chebyshev(self.x, self.y, target.x, target.y) > self.reach) return fail("They are outside your reach.");
		if (target.ap >= 8) return fail("They cannot hold more AP.");
		self.ap -= 1;
		target.ap += 1;
		snapshotPly(next, `${nationLabel(self)} sends 1 AP to ${nationLabel(target)}.`, null);
		return {
			ok: true,
			game: next,
			toast: `Sent 1 AP to ${target.name}.`,
			victory: false
		};
	}
	const line = `${nationLabel(self)} is eliminated by abdication.`;
	self.alive = false;
	self.hp = 0;
	self.eliminatedBy = "abdication";
	snapshotPly(next, line, line);
	const victory = closeIfAlone(next, now);
	return {
		ok: true,
		game: next,
		toast: victory ? null : "Abdication is recorded.",
		victory
	};
}
function inReach(self, other) {
	return other.alive && other.id !== self.id && chebyshev(self.x, self.y, other.x, other.y) <= self.reach;
}
var KEY = "alliance.v1";
var ARCHIVE_LIMIT = 20;
var EMPTY_SAVE = {
	version: 1,
	confirm: false,
	live: null,
	archive: []
};
function isGame(value) {
	if (!value || typeof value !== "object") return false;
	const game = value;
	return typeof game.id === "string" && Array.isArray(game.nations) && Array.isArray(game.plies) && game.plies.length > 0 && typeof game.hour === "number";
}
function loadSave() {
	if (typeof localStorage === "undefined") return EMPTY_SAVE;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return EMPTY_SAVE;
		const parsed = JSON.parse(raw);
		return {
			version: 1,
			confirm: parsed.confirm === true,
			live: isGame(parsed.live) ? parsed.live : null,
			archive: Array.isArray(parsed.archive) ? parsed.archive.filter(isGame) : []
		};
	} catch {
		return EMPTY_SAVE;
	}
}
function writeSave(save) {
	localStorage.setItem(KEY, JSON.stringify({
		...save,
		archive: save.archive.slice(0, ARCHIVE_LIMIT)
	}));
}
function rememberGame(save, game) {
	if (!game.finishedAt) return {
		...save,
		live: game
	};
	const archive = [game, ...save.archive.filter((item) => item.id !== game.id)].slice(0, ARCHIVE_LIMIT);
	return {
		...save,
		live: game,
		archive
	};
}
function btn(kind = "ghost") {
	const base = "inline-flex h-11 items-center justify-center gap-2 rounded-lg px-3 text-sm font-medium disabled:opacity-40";
	if (kind === "solid") return `${base} bg-brass text-bg`;
	if (kind === "quiet") return `${base} text-muted`;
	return `${base} border border-line bg-surface text-fg`;
}
function Flag({ iso, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: `/flags/${iso}.svg`,
		alt: "",
		draggable: false,
		className: `object-cover ${className}`
	});
}
function AllianceApp() {
	const [booted, setBooted] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)({ kind: "home" });
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [live, setLive] = (0, import_react.useState)(null);
	const [archive, setArchive] = (0, import_react.useState)([]);
	const [pending, setPending] = (0, import_react.useState)(null);
	const [cloud, setCloud] = (0, import_react.useState)(null);
	const saveRef = (0, import_react.useRef)({
		version: 1,
		confirm: false,
		live: null,
		archive: []
	});
	const liveRef = (0, import_react.useRef)(null);
	liveRef.current = live;
	(0, import_react.useEffect)(() => {
		const save = loadSave();
		saveRef.current = save;
		setConfirm(save.confirm);
		setLive(save.live);
		setArchive(save.archive);
		setBooted(true);
		getCloudStatus().then((status) => setCloud(status.ready)).catch(() => setCloud(false));
	}, []);
	(0, import_react.useEffect)(() => {
		const probe = window;
		probe.__alliance = {
			phase: phase.kind,
			confirm,
			victory: live ? victoryLine(live) : null,
			chronicle: live ? chronicleOf(live) : []
		};
	}, [
		phase,
		confirm,
		live
	]);
	function store(next) {
		saveRef.current = next;
		writeSave(next);
		setConfirm(next.confirm);
		setLive(next.live);
		setArchive(next.archive);
	}
	function play(action, opts) {
		const current = liveRef.current;
		if (!current) return;
		const preview = applyAction(current, action);
		if (!preview.ok) {
			toast.error(preview.toast);
			return;
		}
		const run = () => {
			const latest = liveRef.current;
			const result = latest ? applyAction(latest, action) : preview;
			setPending(null);
			if (!result.ok) {
				toast.error(result.toast);
				return;
			}
			store(rememberGame(saveRef.current, result.game));
			if (result.toast) toast.success(result.toast);
			opts.onDone?.();
		};
		if (opts.always || saveRef.current.confirm) setPending({
			title: opts.title,
			detail: opts.detail,
			run
		});
		else run();
	}
	function begin(title, seats, cells) {
		const game = createGame({
			title,
			seats,
			cells
		});
		store({
			...saveRef.current,
			live: game
		});
		setPhase({ kind: "match" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				duration: 2200
			}),
			phase.kind === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home, {
				booted,
				live,
				archiveCount: archive.length,
				onDrill: () => setPhase({
					kind: "lobby",
					drill: true
				}),
				onNew: () => setPhase({
					kind: "lobby",
					drill: false
				}),
				onResume: () => setPhase({ kind: "match" }),
				onArchive: () => setPhase({ kind: "archive" }),
				onCodex: () => setPhase({ kind: "codex" }),
				onAnalyse: () => {
					if (!live) return;
					setPhase({
						kind: "analyse",
						game: live,
						cursor: live.plies.length - 1
					});
				}
			}),
			phase.kind === "lobby" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lobby, {
				drill: phase.drill,
				onCancel: () => setPhase({ kind: "home" }),
				onStart: begin
			}),
			phase.kind === "match" && live && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, {
				game: live,
				confirm,
				locked: pending !== null,
				onToggleConfirm: () => store({
					...saveRef.current,
					confirm: !saveRef.current.confirm
				}),
				onPlay: play,
				onHome: () => setPhase({ kind: "home" }),
				onAnalyse: () => setPhase({
					kind: "analyse",
					game: live,
					cursor: live.plies.length - 1
				}),
				onDiscard: () => {
					store({
						...saveRef.current,
						live: null
					});
					setPhase({ kind: "home" });
				}
			}),
			phase.kind === "analyse" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Analyse, {
				game: phase.game,
				cursor: phase.cursor,
				onCursor: (cursor) => setPhase({
					...phase,
					cursor
				}),
				onHome: () => setPhase({ kind: "home" })
			}),
			phase.kind === "archive" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, {
				games: archive,
				onOpen: (game) => setPhase({
					kind: "analyse",
					game,
					cursor: game.plies.length - 1
				}),
				onHome: () => setPhase({ kind: "home" }),
				onImport: (game) => setPhase({
					kind: "analyse",
					game,
					cursor: game.plies.length - 1
				})
			}),
			phase.kind === "codex" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Codex, {
				cloud,
				onHome: () => setPhase({ kind: "home" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				pending,
				onCancel: () => setPending(null)
			})
		]
	});
}
function Home({ booted, live, archiveCount, onDrill, onNew, onResume, onArchive, onCodex, onAnalyse }) {
	const ended = live?.finishedAt ? victoryLine(live) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-md flex-col px-5 py-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-brass",
				children: "Project"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-5xl leading-none",
				children: "Alliance"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xs text-muted",
				children: "One map. Lives stay hidden. The last nation rules."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-2",
				children: [
					booted && live && !live.finishedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btn("solid"),
						onClick: onResume,
						children: "Resume table"
					}),
					booted && ended && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btn("solid"),
						onClick: onAnalyse,
						children: ended
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btn(live && !live.finishedAt ? "ghost" : "solid"),
						onClick: onDrill,
						children: "Four-nation drill"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btn(),
						onClick: onNew,
						children: "New table"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: btn(),
						onClick: onArchive,
						children: ["Records", archiveCount ? ` · ${archiveCount}` : ""]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: btn("quiet"),
						onClick: onCodex,
						children: "Codex"
					})
				]
			})
		]
	});
}
function Lobby({ drill, onCancel, onStart }) {
	const [title, setTitle] = (0, import_react.useState)(drill ? "Four-nation drill" : "Table");
	const [seats, setSeats] = (0, import_react.useState)(drill ? DRILL.map((seat) => ({ ...seat })) : DRILL.slice(0, 2));
	const [picker, setPicker] = (0, import_react.useState)(null);
	const [countdown, setCountdown] = (0, import_react.useState)(null);
	const seatsRef = (0, import_react.useRef)(seats);
	const titleRef = (0, import_react.useRef)(title);
	const started = (0, import_react.useRef)(false);
	seatsRef.current = seats;
	titleRef.current = title;
	function begin() {
		if (started.current) return;
		const current = seatsRef.current;
		const names = current.map((seat) => seat.name.trim());
		if (names.some((name) => name.length === 0)) {
			toast.error("Every nation needs a name.");
			setCountdown(null);
			return;
		}
		if (new Set(names.map((name) => name.toLowerCase())).size !== names.length) {
			toast.error("Each player needs a distinct name.");
			setCountdown(null);
			return;
		}
		if (new Set(current.map((seat) => seat.iso)).size !== current.length) {
			toast.error("Each country is chosen once.");
			setCountdown(null);
			return;
		}
		started.current = true;
		setCountdown(null);
		const cells = drill && current.length === DRILL.length ? DRILL_CELLS : void 0;
		onStart(titleRef.current, current.map((seat) => ({
			name: seat.name.trim(),
			iso: seat.iso
		})), cells);
	}
	(0, import_react.useEffect)(() => {
		if (countdown === null) return;
		if (countdown <= 0) {
			begin();
			return;
		}
		const id = window.setTimeout(() => setCountdown((value) => value === null ? value : value - 1), 1e3);
		return () => window.clearTimeout(id);
	}, [countdown]);
	function addSeat() {
		const next = COUNTRIES.find((country) => !seats.some((seat) => seat.iso === country.iso));
		if (!next || seats.length >= 6) return;
		setSeats((current) => [...current, {
			name: "",
			iso: next.iso
		}]);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-md flex-col px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${btn("quiet")} self-start px-0`,
				onClick: onCancel,
				children: "Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl leading-none",
				children: drill ? "Drill" : "New table"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mt-5 text-sm text-muted",
				htmlFor: "table-name",
				children: "Table"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "table-name",
				value: title,
				maxLength: 32,
				onChange: (event) => setTitle(event.target.value),
				className: "mt-1 h-11 rounded-lg border border-line bg-surface px-3 text-sm outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-brass"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-2",
				children: seats.map((seat, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: `${btn()} w-36 shrink-0 px-2`,
							onClick: () => setPicker(index),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
								iso: seat.iso,
								className: "h-4 w-6 rounded-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: countryByIso(seat.iso)?.name
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							"aria-label": `Name for ${countryByIso(seat.iso)?.name}`,
							value: seat.name,
							maxLength: 24,
							onChange: (event) => setSeats((current) => current.map((item, itemIndex) => itemIndex === index ? {
								...item,
								name: event.target.value
							} : item)),
							className: "h-11 min-w-0 flex-1 rounded-lg border border-line bg-surface px-3 text-sm outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-brass"
						}),
						seats.length > 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btn()} w-11 px-0`,
							"aria-label": `Remove ${seat.name || "nation"}`,
							onClick: () => setSeats((current) => current.filter((_, itemIndex) => itemIndex !== index)),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})
					]
				}, `${seat.iso}-${index}`))
			}),
			seats.length < 6 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: `${btn("quiet")} mt-2 self-start`,
				onClick: addSeat,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Add nation"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btn("solid"),
					onClick: begin,
					children: "Immediately start"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btn(),
					onClick: () => setCountdown(10),
					children: "Lock in ten seconds"
				})]
			}),
			countdown !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-30 flex flex-col items-center justify-center bg-bg/80",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-7xl",
					children: countdown
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: `${btn()} mt-4`,
					onClick: () => setCountdown(null),
					children: "Cancel"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountryPicker, {
				open: picker !== null,
				taken: seats.map((seat) => seat.iso),
				onClose: () => setPicker(null),
				onPick: (iso) => {
					if (picker === null) return;
					setSeats((current) => current.map((seat, index) => index === picker ? {
						...seat,
						iso
					} : seat));
					setPicker(null);
				}
			})
		]
	});
}
function CountryPicker({ open, taken, onClose, onPick }) {
	const [query, setQuery] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (open) setQuery("");
	}, [open]);
	const shown = COUNTRIES.filter((country) => country.name.toLowerCase().includes(query.trim().toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => !next && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed inset-x-4 top-16 z-50 mx-auto flex max-h-96 max-w-md flex-col rounded-lg border border-line bg-surface p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-2xl",
					children: "Country"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "Search",
					className: "mt-2 h-11 rounded-lg border border-line bg-bg px-3 text-sm outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 overflow-auto",
					children: shown.map((country) => {
						const used = taken.includes(country.iso);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: used,
							className: "flex h-11 w-full items-center gap-2 rounded-lg px-2 text-left text-sm disabled:opacity-40",
							onClick: () => onPick(country.iso),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
								iso: country.iso,
								className: "h-4 w-6 rounded-sm"
							}), country.name]
						}) }, country.iso);
					})
				})
			]
		})] })
	});
}
function Match({ game, confirm, locked, onToggleConfirm, onPlay, onHome, onAnalyse, onDiscard }) {
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const [sendMode, setSendMode] = (0, import_react.useState)(false);
	const [chronicleOpen, setChronicleOpen] = (0, import_react.useState)(false);
	const [hover, setHover] = (0, import_react.useState)(null);
	const [pinned, setPinned] = (0, import_react.useState)(false);
	const selected = game.nations.find((nation) => nation.id === selectedId && nation.alive) ?? null;
	const ended = victoryLine(game);
	const lines = chronicleOf(game);
	(0, import_react.useEffect)(() => {
		if (!selected) setSendMode(false);
	}, [selected]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (locked || ended || !selected) return;
			if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
			const delta = {
				ArrowUp: [0, -1],
				ArrowDown: [0, 1],
				ArrowLeft: [-1, 0],
				ArrowRight: [1, 0]
			}[event.key];
			if (!delta) {
				if (event.key === "Escape") {
					setSelectedId(null);
					setSendMode(false);
				}
				return;
			}
			event.preventDefault();
			march(selected.x + delta[0], selected.y + delta[1], selected);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		locked,
		ended,
		selected,
		confirm
	]);
	function march(x, y, actor) {
		onPlay({
			type: "march",
			id: actor.id,
			x,
			y
		}, {
			title: `March ${directionName(x - actor.x, y - actor.y)}?`,
			detail: `${actor.name} spends 1 AP.`
		});
	}
	function onCell(x, y, point) {
		if (ended) return;
		const occupant = game.nations.find((nation) => nation.x === x && nation.y === y) ?? null;
		if (sendMode && selected) {
			if (occupant?.alive && occupant.id !== selected.id && inReach(selected, occupant)) onPlay({
				type: "send",
				id: selected.id,
				targetId: occupant.id
			}, {
				title: `Send 1 AP to ${occupant.name}?`,
				detail: `${selected.name} spends 1 AP.`,
				always: true,
				onDone: () => setSendMode(false)
			});
			else if (occupant?.alive) toast.error("They are outside your reach.");
			else toast.error("Choose a living nation.");
			return;
		}
		if (selected && occupant?.id === selected.id) {
			setSelectedId(null);
			setPinned(false);
			return;
		}
		if (selected && occupant?.alive) {
			if (inReach(selected, occupant)) onPlay({
				type: "strike",
				id: selected.id,
				targetId: occupant.id
			}, {
				title: `Strike ${occupant.country}?`,
				detail: `${selected.name} spends 1 AP.`
			});
			else toast.error("They are outside your reach.");
			return;
		}
		if (selected && isLand(x, y) && !occupant && isOrthogonalStep(selected.x, selected.y, x, y)) {
			march(x, y, selected);
			return;
		}
		if (selected && !isLand(x, y) && isOrthogonalStep(selected.x, selected.y, x, y)) {
			toast.error("The sea is closed.");
			return;
		}
		if (selected && occupant && !occupant.alive && isOrthogonalStep(selected.x, selected.y, x, y)) {
			toast.error("A gravestone holds that square.");
			return;
		}
		if (selected) {
			toast.error("That square is not beside you.");
			return;
		}
		if (occupant?.alive) {
			setSelectedId(occupant.id);
			setPinned(false);
			setHover(null);
			return;
		}
		if (occupant) {
			setPinned(true);
			setHover({
				nation: occupant,
				x: point.clientX,
				y: point.clientY
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-line px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "min-w-0 flex-1 text-left",
						onClick: onHome,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate font-display text-2xl leading-none",
							children: "Alliance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: ["Hour ", game.hour]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-pressed": confirm,
						onClick: onToggleConfirm,
						className: confirm ? btn("solid") : btn(),
						children: "Confirm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `${btn()} w-11 px-0`,
						"aria-label": "Chronicle",
						"aria-expanded": chronicleOpen,
						onClick: () => setChronicleOpen((open) => !open),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollText, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: `${btn()} w-11 px-0`,
						"aria-label": "Sound the next bell",
						disabled: Boolean(ended),
						onClick: () => onPlay({ type: "bell" }, {
							title: "Sound the next bell?",
							detail: "Living nations gain 2 AP.",
							always: true
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-0 flex-1 overflow-auto p-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {
					nations: game.nations,
					selectedId: selected?.id ?? null,
					sendMode,
					reveal: false,
					onCell,
					onHover: (next) => {
						if (next) {
							setPinned(false);
							setHover(next);
						} else if (!pinned) setHover(null);
					}
				}), chronicleOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "absolute inset-y-2 right-2 z-20 flex w-64 max-w-[80%] flex-col rounded-lg border border-line bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Chronicle"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: `${btn("quiet")} h-9 w-9 px-0`,
							"aria-label": "Close chronicle",
							onClick: () => setChronicleOpen(false),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-auto px-3 pb-3",
						children: lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "No nation has fallen."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "flex flex-col gap-3",
							children: lines.map((line, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-sm",
								children: line
							}, `${index}-${line}`))
						})
					})]
				})]
			}),
			selected && !ended && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 border-t border-line px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
						iso: selected.iso,
						className: "h-6 w-8 rounded-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-sm font-medium",
							children: selected.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted",
							children: [
								selected.country,
								" · ",
								selected.ap,
								" AP"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex flex-wrap items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { onStep: (dx, dy) => march(selected.x + dx, selected.y + dy, selected) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btn(),
								onClick: () => onPlay({
									type: "extend",
									id: selected.id
								}, {
									title: "Extend reach?",
									detail: `${selected.name} spends 2 AP.`
								}),
								children: "Reach"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-pressed": sendMode,
								className: sendMode ? btn("solid") : btn(),
								onClick: () => setSendMode((value) => !value),
								children: "Send"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btn(),
								onClick: () => onPlay({
									type: "abdicate",
									id: selected.id
								}, {
									title: "Abdicate?",
									detail: `${nationLabel(selected)} leaves the map.`,
									always: true,
									onDone: () => setSelectedId(null)
								}),
								children: "Abdicate"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: btn("quiet"),
								onClick: () => setSelectedId(null),
								children: "Stand up"
							})
						]
					})
				]
			}),
			hover && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCard, {
				nation: hover.nation,
				x: hover.x,
				y: hover.y,
				reveal: false
			}),
			ended && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40 flex items-center justify-center bg-bg/75 px-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm rounded-lg border border-line bg-surface p-5 text-center",
					role: "dialog",
					"aria-labelledby": "victory-title",
					children: [
						game.winnerId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
							iso: game.nations.find((nation) => nation.id === game.winnerId)?.iso ?? "br",
							className: "mx-auto mb-3 h-12 w-16 rounded-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "victory-title",
							className: "font-display text-3xl leading-tight",
							children: ended
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: btn("solid"),
									onClick: onAnalyse,
									children: "Analyse the record"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: btn(),
									onClick: onHome,
									children: "Leave the table"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: btn("quiet"),
									onClick: onDiscard,
									children: "Discard"
								})
							]
						})
					]
				})
			})
		]
	});
}
function Compass({ onStep }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1",
		children: [
			{
				label: "March north",
				dx: 0,
				dy: -1,
				icon: ChevronUp
			},
			{
				label: "March west",
				dx: -1,
				dy: 0,
				icon: ChevronLeft
			},
			{
				label: "March south",
				dx: 0,
				dy: 1,
				icon: ChevronDown
			},
			{
				label: "March east",
				dx: 1,
				dy: 0,
				icon: ChevronRight
			}
		].map((pad) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: `${btn()} w-11 px-0`,
			"aria-label": pad.label,
			onClick: () => onStep(pad.dx, pad.dy),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(pad.icon, { className: "size-4" })
		}, pad.label))
	});
}
function Board({ nations, selectedId, sendMode, reveal, onCell, onHover }) {
	const selected = nations.find((nation) => nation.id === selectedId && nation.alive) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto grid w-full max-w-3xl overflow-hidden rounded-lg border border-line",
		style: { gridTemplateColumns: `repeat(8, minmax(0, 1fr))` },
		children: Array.from({ length: 48 }, (_, index) => {
			const x = index % 8;
			const y = Math.floor(index / 8);
			const occupant = nations.find((nation) => nation.x === x && nation.y === y) ?? null;
			const land = isLand(x, y);
			const beside = selected !== null && land && !occupant && isOrthogonalStep(selected.x, selected.y, x, y);
			const strike = selected !== null && !sendMode && occupant !== null && occupant.alive && inReach(selected, occupant);
			const send = sendMode && selected !== null && occupant !== null && occupant.alive && inReach(selected, occupant);
			const mine = occupant?.id === selectedId && occupant.alive;
			let tone = "bg-sea";
			if (land) tone = (x + y) % 2 === 0 ? "bg-land" : "bg-land-deep";
			if (beside) tone = "bg-land-bright";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": occupant ? `${occupant.name}, ${occupant.country}${occupant.alive ? "" : ", fallen"}` : land ? "Land" : "Sea",
				className: `relative flex aspect-square items-center justify-center border border-line ${tone} ${mine || send ? "ring-2 ring-brass ring-inset" : ""} ${strike ? "ring-2 ring-blood ring-inset" : ""}`,
				onClick: (event) => onCell(x, y, event),
				onPointerEnter: (event) => {
					if (occupant) onHover({
						nation: occupant,
						x: event.clientX,
						y: event.clientY
					});
				},
				onPointerMove: (event) => {
					if (occupant) onHover({
						nation: occupant,
						x: event.clientX,
						y: event.clientY
					});
				},
				onPointerLeave: () => onHover(null),
				children: occupant && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Token, {
					nation: occupant,
					reveal
				})
			}, `${x}-${y}`);
		})
	});
}
function Token({ nation, reveal }) {
	if (!nation.alive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex flex-col items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-4 w-5 rounded-t-lg rounded-b-sm bg-surface-2" }), reveal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mt-0.5 text-xs leading-none text-muted",
			children: ["0·", nation.ap]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "relative flex flex-col items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
			iso: nation.iso,
			className: "h-6 w-8 rounded-sm"
		}), reveal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mt-0.5 rounded bg-bg px-1 text-xs leading-none text-fg",
			children: [
				nation.hp,
				"·",
				nation.ap
			]
		})]
	});
}
function HoverCard({ nation, x, y, reveal }) {
	const left = typeof window === "undefined" ? x : Math.max(8, Math.min(x + 14, window.innerWidth - 188));
	const top = typeof window === "undefined" ? y : Math.max(8, Math.min(y + 14, window.innerHeight - 132));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none fixed z-30 w-44 rounded-lg border border-line bg-surface p-2",
		style: {
			left,
			top
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, {
				iso: nation.iso,
				className: "mb-2 h-8 w-12 rounded-sm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm font-medium leading-tight",
				children: nation.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm text-muted",
				children: nation.country
			}),
			reveal && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 text-sm",
				children: [
					nation.hp,
					" health · ",
					nation.ap,
					" AP · reach ",
					nation.reach
				]
			})
		]
	});
}
function Analyse({ game, cursor, onCursor, onHome }) {
	const last = game.plies.length - 1;
	const safe = Math.max(0, Math.min(cursor, last));
	const ply = game.plies[safe];
	const [hover, setHover] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			if (event.key === "ArrowLeft") onCursor(Math.max(0, safe - 1));
			if (event.key === "ArrowRight") onCursor(Math.min(last, safe + 1));
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		last,
		onCursor,
		safe
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-line px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "min-w-0 flex-1 text-left",
					onClick: onHome,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-2xl leading-none",
						children: "Record"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate text-xs text-muted",
						children: victoryLine(game) ?? game.title
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: btn(),
					onClick: () => downloadRecord(game),
					children: "Download"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-auto p-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {
					nations: ply.snapshot,
					selectedId: null,
					sendMode: false,
					reveal: true,
					onCell: (x, y, point) => {
						const occupant = ply.snapshot.find((nation) => nation.x === x && nation.y === y);
						setHover(occupant ? {
							nation: occupant,
							x: point.clientX,
							y: point.clientY
						} : null);
					},
					onHover: setHover
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-3 max-w-3xl text-xs text-muted",
					children: "Health · AP on each flag. Hover for reach."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line px-3 py-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-3xl flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `${btn()} w-11 px-0`,
								"aria-label": "Opening",
								onClick: () => onCursor(0),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsLeft, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `${btn()} w-11 px-0`,
								"aria-label": "Previous action",
								onClick: () => onCursor(Math.max(0, safe - 1)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-14 text-center text-sm",
								children: [
									safe,
									" / ",
									last
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `${btn()} w-11 px-0`,
								"aria-label": "Next action",
								onClick: () => onCursor(Math.min(last, safe + 1)),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `${btn()} w-11 px-0`,
								"aria-label": "Latest",
								onClick: () => onCursor(last),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsRight, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "sr-only",
								htmlFor: "ply",
								children: "Action"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								id: "ply",
								className: "min-w-0 flex-1",
								type: "range",
								min: 0,
								max: last,
								value: safe,
								onChange: (event) => onCursor(Number(event.target.value))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm",
						children: [
							"Hour ",
							ply.hour,
							". ",
							ply.text
						]
					})]
				})
			}),
			hover && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HoverCard, {
				nation: hover.nation,
				x: hover.x,
				y: hover.y,
				reveal: true
			})
		]
	});
}
function Archive({ games, onOpen, onHome, onImport }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-md flex-col px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${btn("quiet")} self-start px-0`,
				onClick: onHome,
				children: "Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Records"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: `${btn()} mt-4`,
				children: ["Open a record", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "application/json",
					className: "sr-only",
					onChange: async (event) => {
						const file = event.target.files?.[0];
						event.target.value = "";
						if (!file) return;
						try {
							const parsed = JSON.parse(await file.text());
							if (!isGame(parsed)) {
								toast.error("That record could not be read.");
								return;
							}
							onImport(parsed);
						} catch {
							toast.error("That record could not be read.");
						}
					}
				})]
			}),
			games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted",
				children: "Finished tables are kept here, ready to step through."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-2",
				children: games.map((game) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "w-full rounded-lg border border-line bg-surface px-3 py-3 text-left",
					onClick: () => onOpen(game),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-medium",
						children: victoryLine(game)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "mt-1 block text-xs text-muted",
						children: [
							game.title,
							" · ",
							Math.max(0, game.plies.length - 1),
							" actions"
						]
					})]
				}) }, game.id))
			})
		]
	});
}
function Codex({ cloud, onHome }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh max-w-md flex-col px-5 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: `${btn("quiet")} self-start px-0`,
				onClick: onHome,
				children: "Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Codex"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-3",
				children: [
					"March to a neighboring land square for 1 AP. The sea, nations, and gravestones block the step.",
					"Strike a nation inside your reach for 1 AP. The third blow eliminates them. Lives are never shown.",
					"Extend reach for 2 AP. Send 1 AP to a nation inside your reach. Abdicate to leave the map.",
					"Sound the bell to advance the hour. Living nations gain 2 AP.",
					"The chronicle names only the blow that ends a nation.",
					"When one nation remains, they rule the world. The record can be analysed with health, AP, and reach visible.",
					"Confirm asks before an action. Abdication, sending AP, and the bell always ask."
				].map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-fg",
					children: rule
				}, rule))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted",
				children: cloud ? "Shared tables are connected. Health and action points stay off the public board." : "This table stays on this device. Shared rooms open once Supabase is connected."
			})
		]
	});
}
function ConfirmDialog({ pending, onCancel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: pending !== null,
		onOpenChange: (open) => !open && onCancel(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, { className: "fixed inset-0 z-40 bg-bg/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
			className: "fixed inset-x-4 top-1/2 z-50 mx-auto max-w-sm -translate-y-1/2 rounded-lg border border-line bg-surface p-4",
			onKeyDown: (event) => {
				if (event.key === "Enter") {
					event.preventDefault();
					pending?.run();
				}
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, {
					className: "font-display text-3xl leading-tight",
					children: pending?.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
					className: "mt-1 text-sm text-muted",
					children: pending?.detail
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						className: btn(),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						className: btn("solid"),
						onClick: () => pending?.run(),
						children: "Confirm"
					})]
				})
			]
		})] })
	});
}
function downloadRecord(game) {
	const blob = new Blob([JSON.stringify(game, null, 2)], { type: "application/json" });
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = `${game.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "alliance"}-record.json`;
	link.click();
	URL.revokeObjectURL(url);
}
var SplitComponent = AllianceApp;
//#endregion
export { SplitComponent as component };
