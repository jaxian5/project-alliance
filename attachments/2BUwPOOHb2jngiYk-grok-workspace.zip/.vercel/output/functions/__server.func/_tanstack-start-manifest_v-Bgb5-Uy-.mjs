//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bgb5-Uy-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CcZFURlE.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CcZFURlE.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CtncumTM.js"]
	}
} });
//#endregion
export { tsrStartManifest };
