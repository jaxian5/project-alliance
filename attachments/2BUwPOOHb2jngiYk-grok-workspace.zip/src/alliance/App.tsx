import { useEffect, useRef, useState } from "react";
import * as AlertDialog from "@radix-ui/react-alert-dialog";
import * as Dialog from "@radix-ui/react-dialog";
import {
  Bell,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ChevronUp,
  Plus,
  ScrollText,
  X,
} from "lucide-react";
import { Toaster, toast } from "sonner";
import { HEIGHT, WIDTH, isLand } from "./board.ts";
import { getCloudStatus } from "./cloud.ts";
import { COUNTRIES, countryByIso } from "./countries.ts";
import {
  DRILL,
  DRILL_CELLS,
  applyAction,
  chronicleOf,
  createGame,
  directionName,
  inReach,
  isOrthogonalStep,
  nationLabel,
  victoryLine,
  type Action,
  type Game,
  type Nation,
  type Result,
  type Seat,
} from "./rules.ts";
import { isGame, loadSave, rememberGame, writeSave, type SaveFile } from "./storage.ts";

type Phase =
  | { kind: "home" }
  | { kind: "lobby"; drill: boolean }
  | { kind: "match" }
  | { kind: "archive" }
  | { kind: "codex" }
  | { kind: "analyse"; game: Game; cursor: number };

type Pending = { title: string; detail: string; run: () => void };
type Hover = { nation: Nation; x: number; y: number };
type PlayOptions = { title: string; detail: string; always?: boolean; onDone?: () => void };

function btn(kind: "solid" | "ghost" | "quiet" = "ghost") {
  const base =
    "inline-flex h-11 items-center justify-center gap-2 rounded-lg px-3 text-sm font-medium disabled:opacity-40";
  if (kind === "solid") return `${base} bg-brass text-bg`;
  if (kind === "quiet") return `${base} text-muted`;
  return `${base} border border-line bg-surface text-fg`;
}

function Flag({ iso, className = "" }: { iso: string; className?: string }) {
  return (
    <img
      src={`/flags/${iso}.svg`}
      alt=""
      draggable={false}
      className={`object-cover ${className}`}
    />
  );
}

export function AllianceApp() {
  const [booted, setBooted] = useState(false);
  const [phase, setPhase] = useState<Phase>({ kind: "home" });
  const [confirm, setConfirm] = useState(false);
  const [live, setLive] = useState<Game | null>(null);
  const [archive, setArchive] = useState<Game[]>([]);
  const [pending, setPending] = useState<Pending | null>(null);
  const [cloud, setCloud] = useState<boolean | null>(null);
  const saveRef = useRef<SaveFile>({ version: 1, confirm: false, live: null, archive: [] });
  const liveRef = useRef<Game | null>(null);
  liveRef.current = live;

  useEffect(() => {
    const save = loadSave();
    saveRef.current = save;
    setConfirm(save.confirm);
    setLive(save.live);
    setArchive(save.archive);
    setBooted(true);
    getCloudStatus()
      .then((status) => setCloud(status.ready))
      .catch(() => setCloud(false));
  }, []);

  useEffect(() => {
    const probe = window as Window & {
      __alliance?: {
        phase: string;
        confirm: boolean;
        victory: string | null;
        chronicle: string[];
      };
    };
    probe.__alliance = {
      phase: phase.kind,
      confirm,
      victory: live ? victoryLine(live) : null,
      chronicle: live ? chronicleOf(live) : [],
    };
  }, [phase, confirm, live]);

  function store(next: SaveFile) {
    saveRef.current = next;
    liveRef.current = next.live;
    writeSave(next);
    setConfirm(next.confirm);
    setLive(next.live);
    setArchive(next.archive);
  }

  function play(action: Action, opts: PlayOptions) {
    const current = liveRef.current;
    if (!current) return;
    const preview = applyAction(current, action);
    if (!preview.ok) {
      toast.error(preview.toast);
      return;
    }
    const run = () => {
      const latest = liveRef.current;
      const result: Result = latest ? applyAction(latest, action) : preview;
      setPending(null);
      if (!result.ok) {
        toast.error(result.toast);
        return;
      }
      store(rememberGame(saveRef.current, result.game));
      if (result.toast) toast.success(result.toast);
      opts.onDone?.();
    };
    if (opts.always || saveRef.current.confirm) setPending({ title: opts.title, detail: opts.detail, run });
    else run();
  }

  function begin(title: string, seats: Seat[], cells?: { x: number; y: number }[]) {
    const game = createGame({ title, seats, cells });
    store({ ...saveRef.current, live: game });
    setPhase({ kind: "match" });
  }

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Toaster position="top-center" duration={2200} />
      {phase.kind === "home" && (
        <Home
          booted={booted}
          live={live}
          archiveCount={archive.length}
          onDrill={() => setPhase({ kind: "lobby", drill: true })}
          onNew={() => setPhase({ kind: "lobby", drill: false })}
          onResume={() => setPhase({ kind: "match" })}
          onArchive={() => setPhase({ kind: "archive" })}
          onCodex={() => setPhase({ kind: "codex" })}
          onAnalyse={() => {
            if (!live) return;
            setPhase({ kind: "analyse", game: live, cursor: live.plies.length - 1 });
          }}
        />
      )}
      {phase.kind === "lobby" && (
        <Lobby
          drill={phase.drill}
          onCancel={() => setPhase({ kind: "home" })}
          onStart={begin}
        />
      )}
      {phase.kind === "match" && live && (
        <Match
          game={live}
          confirm={confirm}
          locked={pending !== null}
          onToggleConfirm={() => store({ ...saveRef.current, confirm: !saveRef.current.confirm })}
          onPlay={play}
          onHome={() => setPhase({ kind: "home" })}
          onAnalyse={() => setPhase({ kind: "analyse", game: live, cursor: live.plies.length - 1 })}
          onDiscard={() => {
            store({ ...saveRef.current, live: null });
            setPhase({ kind: "home" });
          }}
        />
      )}
      {phase.kind === "analyse" && (
        <Analyse
          game={phase.game}
          cursor={phase.cursor}
          onCursor={(cursor) => setPhase({ ...phase, cursor })}
          onHome={() => setPhase({ kind: "home" })}
        />
      )}
      {phase.kind === "archive" && (
        <Archive
          games={archive}
          onOpen={(game) => setPhase({ kind: "analyse", game, cursor: game.plies.length - 1 })}
          onHome={() => setPhase({ kind: "home" })}
          onImport={(game) => setPhase({ kind: "analyse", game, cursor: game.plies.length - 1 })}
        />
      )}
      {phase.kind === "codex" && <Codex cloud={cloud} onHome={() => setPhase({ kind: "home" })} />}
      <ConfirmDialog pending={pending} onCancel={() => setPending(null)} />
    </div>
  );
}

function Home({
  booted,
  live,
  archiveCount,
  onDrill,
  onNew,
  onResume,
  onArchive,
  onCodex,
  onAnalyse,
}: {
  booted: boolean;
  live: Game | null;
  archiveCount: number;
  onDrill: () => void;
  onNew: () => void;
  onResume: () => void;
  onArchive: () => void;
  onCodex: () => void;
  onAnalyse: () => void;
}) {
  const ended = live?.finishedAt ? victoryLine(live) : null;
  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col px-5 py-12">
      <p className="text-sm text-brass">Project</p>
      <h1 className="font-display text-5xl leading-none">Alliance</h1>
      <p className="mt-3 max-w-xs text-muted">One map. Lives stay hidden. The last nation rules.</p>
      <div className="mt-8 flex flex-col gap-2">
        {booted && live && !live.finishedAt && (
          <button type="button" className={btn("solid")} onClick={onResume}>
            Resume table
          </button>
        )}
        {booted && ended && (
          <button type="button" className={btn("solid")} onClick={onAnalyse}>
            {ended}
          </button>
        )}
        <button type="button" className={btn(live && !live.finishedAt ? "ghost" : "solid")} onClick={onDrill}>
          Four-nation drill
        </button>
        <button type="button" className={btn()} onClick={onNew}>
          New table
        </button>
        <button type="button" className={btn()} onClick={onArchive}>
          Records{archiveCount ? ` · ${archiveCount}` : ""}
        </button>
        <button type="button" className={btn("quiet")} onClick={onCodex}>
          Codex
        </button>
      </div>
    </main>
  );
}

function Lobby({
  drill,
  onCancel,
  onStart,
}: {
  drill: boolean;
  onCancel: () => void;
  onStart: (title: string, seats: Seat[], cells?: { x: number; y: number }[]) => void;
}) {
  const [title, setTitle] = useState(drill ? "Four-nation drill" : "Table");
  const [seats, setSeats] = useState<Seat[]>(drill ? DRILL.map((seat) => ({ ...seat })) : DRILL.slice(0, 2));
  const [picker, setPicker] = useState<number | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const seatsRef = useRef(seats);
  const titleRef = useRef(title);
  const started = useRef(false);
  seatsRef.current = seats;
  titleRef.current = title;

  function begin() {
    if (started.current) return;
    const current = seatsRef.current;
    const names = current.map((seat) => seat.name.trim());
    if (names.some((name) => name.length === 0)) {
      toast.error("Every nation needs a name.");
      setCountdown(null);
      return;
    }
    if (new Set(names.map((name) => name.toLowerCase())).size !== names.length) {
      toast.error("Each player needs a distinct name.");
      setCountdown(null);
      return;
    }
    if (new Set(current.map((seat) => seat.iso)).size !== current.length) {
      toast.error("Each country is chosen once.");
      setCountdown(null);
      return;
    }
    started.current = true;
    setCountdown(null);
    const cells = drill && current.length === DRILL.length ? DRILL_CELLS : undefined;
    onStart(
      titleRef.current,
      current.map((seat) => ({ name: seat.name.trim(), iso: seat.iso })),
      cells,
    );
  }

  useEffect(() => {
    if (countdown === null) return;
    if (countdown <= 0) {
      begin();
      return;
    }
    const id = window.setTimeout(() => setCountdown((value) => (value === null ? value : value - 1)), 1000);
    return () => window.clearTimeout(id);
  }, [countdown]);

  function addSeat() {
    const next = COUNTRIES.find((country) => !seats.some((seat) => seat.iso === country.iso));
    if (!next || seats.length >= 6) return;
    setSeats((current) => [...current, { name: "", iso: next.iso }]);
  }

  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col px-5 py-8">
      <button type="button" className={`${btn("quiet")} self-start px-0`} onClick={onCancel}>
        Back
      </button>
      <h1 className="font-display text-4xl leading-none">{drill ? "Drill" : "New table"}</h1>
      <label className="mt-5 text-sm text-muted" htmlFor="table-name">
        Table
      </label>
      <input
        id="table-name"
        value={title}
        maxLength={32}
        onChange={(event) => setTitle(event.target.value)}
        className="mt-1 h-11 rounded-lg border border-line bg-surface px-3 text-sm outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-brass"
      />
      <ul className="mt-4 flex flex-col gap-2">
        {seats.map((seat, index) => (
          <li key={`${seat.iso}-${index}`} className="flex items-center gap-2">
            <button type="button" className={`${btn()} w-36 shrink-0 px-2`} onClick={() => setPicker(index)}>
              <Flag iso={seat.iso} className="h-4 w-6 rounded-sm" />
              <span className="truncate">{countryByIso(seat.iso)?.name}</span>
            </button>
            <input
              aria-label={`Name for ${countryByIso(seat.iso)?.name}`}
              value={seat.name}
              maxLength={24}
              onChange={(event) =>
                setSeats((current) =>
                  current.map((item, itemIndex) =>
                    itemIndex === index ? { ...item, name: event.target.value } : item,
                  ),
                )
              }
              className="h-11 min-w-0 flex-1 rounded-lg border border-line bg-surface px-3 text-sm outline-none focus-visible:outline focus-visible:outline-2 focus-visible:outline-brass"
            />
            {seats.length > 2 && (
              <button
                type="button"
                className={`${btn()} w-11 px-0`}
                aria-label={`Remove ${seat.name || "nation"}`}
                onClick={() => setSeats((current) => current.filter((_, itemIndex) => itemIndex !== index))}
              >
                <X className="size-4" />
              </button>
            )}
          </li>
        ))}
      </ul>
      {seats.length < 6 && (
        <button type="button" className={`${btn("quiet")} mt-2 self-start`} onClick={addSeat}>
          <Plus className="size-4" />
          Add nation
        </button>
      )}
      <div className="mt-6 flex flex-col gap-2">
        <button type="button" className={btn("solid")} onClick={begin}>
          Immediately start
        </button>
        <button type="button" className={btn()} onClick={() => setCountdown(10)}>
          Lock in ten seconds
        </button>
      </div>
      {countdown !== null && (
        <div className="fixed inset-0 z-30 flex flex-col items-center justify-center bg-bg/80">
          <p className="font-display text-7xl">{countdown}</p>
          <button type="button" className={`${btn()} mt-4`} onClick={() => setCountdown(null)}>
            Cancel
          </button>
        </div>
      )}
      <CountryPicker
        open={picker !== null}
        taken={seats.map((seat) => seat.iso)}
        onClose={() => setPicker(null)}
        onPick={(iso) => {
          if (picker === null) return;
          setSeats((current) => current.map((seat, index) => (index === picker ? { ...seat, iso } : seat)));
          setPicker(null);
        }}
      />
    </main>
  );
}

function CountryPicker({
  open,
  taken,
  onClose,
  onPick,
}: {
  open: boolean;
  taken: string[];
  onClose: () => void;
  onPick: (iso: string) => void;
}) {
  const [query, setQuery] = useState("");
  useEffect(() => {
    if (open) setQuery("");
  }, [open]);
  const shown = COUNTRIES.filter((country) => country.name.toLowerCase().includes(query.trim().toLowerCase()));
  return (
    <Dialog.Root open={open} onOpenChange={(next) => !next && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-bg/70" />
        <Dialog.Content className="fixed inset-x-4 top-16 z-50 mx-auto flex max-h-96 max-w-md flex-col rounded-lg border border-line bg-surface p-3">
          <Dialog.Title className="font-display text-2xl">Country</Dialog.Title>
          <input
            autoFocus
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search"
            className="mt-2 h-11 rounded-lg border border-line bg-bg px-3 text-sm outline-none"
          />
          <ul className="mt-2 overflow-auto">
            {shown.map((country) => {
              const used = taken.includes(country.iso);
              return (
                <li key={country.iso}>
                  <button
                    type="button"
                    disabled={used}
                    className="flex h-11 w-full items-center gap-2 rounded-lg px-2 text-left text-sm disabled:opacity-40"
                    onClick={() => onPick(country.iso)}
                  >
                    <Flag iso={country.iso} className="h-4 w-6 rounded-sm" />
                    {country.name}
                  </button>
                </li>
              );
            })}
          </ul>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

function Match({
  game,
  confirm,
  locked,
  onToggleConfirm,
  onPlay,
  onHome,
  onAnalyse,
  onDiscard,
}: {
  game: Game;
  confirm: boolean;
  locked: boolean;
  onToggleConfirm: () => void;
  onPlay: (action: Action, opts: PlayOptions) => void;
  onHome: () => void;
  onAnalyse: () => void;
  onDiscard: () => void;
}) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [sendMode, setSendMode] = useState(false);
  const [chronicleOpen, setChronicleOpen] = useState(false);
  const [hover, setHover] = useState<Hover | null>(null);
  const [pinned, setPinned] = useState(false);
  const selected = game.nations.find((nation) => nation.id === selectedId && nation.alive) ?? null;
  const ended = victoryLine(game);
  const lines = chronicleOf(game);

  useEffect(() => {
    if (!selected) setSendMode(false);
  }, [selected]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (locked || ended || !selected) return;
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
      const step: Record<string, [number, number]> = {
        ArrowUp: [0, -1],
        ArrowDown: [0, 1],
        ArrowLeft: [-1, 0],
        ArrowRight: [1, 0],
      };
      const delta = step[event.key];
      if (!delta) {
        if (event.key === "Escape") {
          setSelectedId(null);
          setSendMode(false);
        }
        return;
      }
      event.preventDefault();
      march(selected.x + delta[0], selected.y + delta[1], selected);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [locked, ended, selected, confirm]);

  function march(x: number, y: number, actor: Nation) {
    onPlay(
      { type: "march", id: actor.id, x, y },
      { title: `March ${directionName(x - actor.x, y - actor.y)}?`, detail: `${actor.name} spends 1 AP.` },
    );
  }

  function onCell(x: number, y: number, point: { clientX: number; clientY: number }) {
    if (ended) return;
    const occupant = game.nations.find((nation) => nation.x === x && nation.y === y) ?? null;
    if (sendMode && selected) {
      if (occupant?.alive && occupant.id !== selected.id && inReach(selected, occupant)) {
        onPlay(
          { type: "send", id: selected.id, targetId: occupant.id },
          {
            title: `Send 1 AP to ${occupant.name}?`,
            detail: `${selected.name} spends 1 AP.`,
            always: true,
            onDone: () => setSendMode(false),
          },
        );
      } else if (occupant?.alive) toast.error("They are outside your reach.");
      else toast.error("Choose a living nation.");
      return;
    }
    if (selected && occupant?.id === selected.id) {
      setSelectedId(null);
      setPinned(false);
      return;
    }
    if (selected && occupant?.alive) {
      if (inReach(selected, occupant)) {
        onPlay(
          { type: "strike", id: selected.id, targetId: occupant.id },
          { title: `Strike ${occupant.country}?`, detail: `${selected.name} spends 1 AP.` },
        );
      } else {
        setSelectedId(occupant.id);
        setSendMode(false);
        setPinned(false);
      }
      return;
    }
    if (selected && isLand(x, y) && !occupant && isOrthogonalStep(selected.x, selected.y, x, y)) {
      march(x, y, selected);
      return;
    }
    if (selected && !isLand(x, y) && isOrthogonalStep(selected.x, selected.y, x, y)) {
      toast.error("The sea is closed.");
      return;
    }
    if (selected && occupant && !occupant.alive && isOrthogonalStep(selected.x, selected.y, x, y)) {
      toast.error("A gravestone holds that square.");
      return;
    }
    if (selected) {
      toast.error("That square is not beside you.");
      return;
    }
    if (occupant?.alive) {
      setSelectedId(occupant.id);
      setPinned(false);
      setHover(null);
      return;
    }
    if (occupant) {
      setPinned(true);
      setHover({ nation: occupant, x: point.clientX, y: point.clientY });
    }
  }

  return (
    <div className="flex h-dvh flex-col">
      <header className="flex items-center gap-2 border-b border-line px-3 py-2">
        <button type="button" className="min-w-0 flex-1 text-left" onClick={onHome}>
          <span className="block truncate font-display text-2xl leading-none">Alliance</span>
          <span className="text-xs text-muted">Hour {game.hour}</span>
        </button>
        <button
          type="button"
          aria-pressed={confirm}
          onClick={onToggleConfirm}
          className={confirm ? btn("solid") : btn()}
        >
          Confirm
        </button>
        <button
          type="button"
          className={`${btn()} w-11 px-0`}
          aria-label="Chronicle"
          aria-expanded={chronicleOpen}
          onClick={() => setChronicleOpen((open) => !open)}
        >
          <ScrollText className="size-4" />
        </button>
        <button
          type="button"
          className={`${btn()} w-11 px-0`}
          aria-label="Sound the next bell"
          disabled={Boolean(ended)}
          onClick={() =>
            onPlay(
              { type: "bell" },
              { title: "Sound the next bell?", detail: "Living nations gain 2 AP.", always: true },
            )
          }
        >
          <Bell className="size-4" />
        </button>
      </header>
      <div className="relative min-h-0 flex-1 overflow-auto p-2">
        <Board
          nations={game.nations}
          selectedId={selected?.id ?? null}
          sendMode={sendMode}
          reveal={false}
          onCell={onCell}
          onHover={(next) => {
            if (next) {
              setPinned(false);
              setHover(next);
            } else if (!pinned) setHover(null);
          }}
        />
        {chronicleOpen && (
          <aside className="absolute inset-y-2 right-2 z-20 flex w-64 max-w-[80%] flex-col rounded-lg border border-line bg-surface">
            <div className="flex items-center justify-between px-3 py-2">
              <h2 className="text-sm font-medium">Chronicle</h2>
              <button type="button" className={`${btn("quiet")} h-9 w-9 px-0`} aria-label="Close chronicle" onClick={() => setChronicleOpen(false)}>
                <X className="size-4" />
              </button>
            </div>
            <div className="overflow-auto px-3 pb-3">
              {lines.length === 0 ? (
                <p className="text-sm text-muted">No nation has fallen.</p>
              ) : (
                <ul className="flex flex-col gap-3">
                  {lines.map((line, index) => (
                    <li key={`${index}-${line}`} className="text-sm">
                      {line}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </aside>
        )}
      </div>
      {selected && !ended && (
        <div className="flex flex-wrap items-center gap-2 border-t border-line px-3 py-2">
          <Flag iso={selected.iso} className="h-6 w-8 rounded-sm" />
          <div className="min-w-0">
            <div className="truncate text-sm font-medium">{selected.name}</div>
            <div className="text-xs text-muted">
              {selected.country} · {selected.ap} AP
            </div>
          </div>
          <div className="ml-auto flex flex-wrap items-center gap-1">
            <Compass
              onStep={(dx, dy) => march(selected.x + dx, selected.y + dy, selected)}
            />
            <button
              type="button"
              className={btn()}
              onClick={() =>
                onPlay(
                  { type: "extend", id: selected.id },
                  { title: "Extend reach?", detail: `${selected.name} spends 2 AP.` },
                )
              }
            >
              Reach
            </button>
            <button
              type="button"
              aria-pressed={sendMode}
              className={sendMode ? btn("solid") : btn()}
              onClick={() => setSendMode((value) => !value)}
            >
              Send
            </button>
            <button
              type="button"
              className={btn()}
              onClick={() =>
                onPlay(
                  { type: "abdicate", id: selected.id },
                  {
                    title: "Abdicate?",
                    detail: `${nationLabel(selected)} leaves the map.`,
                    always: true,
                    onDone: () => setSelectedId(null),
                  },
                )
              }
            >
              Abdicate
            </button>
            <button type="button" className={btn("quiet")} onClick={() => setSelectedId(null)}>
              Stand up
            </button>
          </div>
        </div>
      )}
      {hover && <HoverCard nation={hover.nation} x={hover.x} y={hover.y} reveal={false} />}
      {ended && (
        <div className="fixed inset-0 z-40 flex items-center justify-center bg-bg/75 px-4">
          <div className="w-full max-w-sm rounded-lg border border-line bg-surface p-5 text-center" role="dialog" aria-labelledby="victory-title">
            {game.winnerId && (
              <Flag
                iso={game.nations.find((nation) => nation.id === game.winnerId)?.iso ?? "br"}
                className="mx-auto mb-3 h-12 w-16 rounded-sm"
              />
            )}
            <h2 id="victory-title" className="font-display text-3xl leading-tight">
              {ended}
            </h2>
            <div className="mt-5 flex flex-col gap-2">
              <button type="button" className={btn("solid")} onClick={onAnalyse}>
                Analyse the record
              </button>
              <button type="button" className={btn()} onClick={onHome}>
                Leave the table
              </button>
              <button type="button" className={btn("quiet")} onClick={onDiscard}>
                Discard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Compass({ onStep }: { onStep: (dx: number, dy: number) => void }) {
  const pads = [
    { label: "March north", dx: 0, dy: -1, icon: ChevronUp },
    { label: "March west", dx: -1, dy: 0, icon: ChevronLeft },
    { label: "March south", dx: 0, dy: 1, icon: ChevronDown },
    { label: "March east", dx: 1, dy: 0, icon: ChevronRight },
  ];
  return (
    <div className="flex gap-1">
      {pads.map((pad) => (
        <button key={pad.label} type="button" className={`${btn()} w-11 px-0`} aria-label={pad.label} onClick={() => onStep(pad.dx, pad.dy)}>
          <pad.icon className="size-4" />
        </button>
      ))}
    </div>
  );
}

function Board({
  nations,
  selectedId,
  sendMode,
  reveal,
  onCell,
  onHover,
}: {
  nations: Nation[];
  selectedId: string | null;
  sendMode: boolean;
  reveal: boolean;
  onCell: (x: number, y: number, point: { clientX: number; clientY: number }) => void;
  onHover: (hover: Hover | null) => void;
}) {
  const selected = nations.find((nation) => nation.id === selectedId && nation.alive) ?? null;
  return (
    <div
      className="mx-auto grid w-full max-w-3xl overflow-hidden rounded-lg border border-line"
      style={{ gridTemplateColumns: `repeat(${WIDTH}, minmax(0, 1fr))` }}
    >
      {Array.from({ length: HEIGHT * WIDTH }, (_, index) => {
        const x = index % WIDTH;
        const y = Math.floor(index / WIDTH);
        const occupant = nations.find((nation) => nation.x === x && nation.y === y) ?? null;
        const land = isLand(x, y);
        const beside =
          selected !== null && land && !occupant && isOrthogonalStep(selected.x, selected.y, x, y);
        const strike =
          selected !== null && !sendMode && occupant !== null && occupant.alive && inReach(selected, occupant);
        const send =
          sendMode && selected !== null && occupant !== null && occupant.alive && inReach(selected, occupant);
        const mine = occupant?.id === selectedId && occupant.alive;
        let tone = "bg-sea";
        if (land) tone = (x + y) % 2 === 0 ? "bg-land" : "bg-land-deep";
        if (beside) tone = "bg-land-bright";
        return (
          <button
            key={`${x}-${y}`}
            type="button"
            aria-label={
              occupant
                ? `${occupant.name}, ${occupant.country}${occupant.alive ? "" : ", fallen"}`
                : land
                  ? "Land"
                  : "Sea"
            }
            className={`relative flex aspect-square items-center justify-center border border-line ${tone} ${
              mine || send ? "ring-2 ring-brass ring-inset" : ""
            } ${strike ? "ring-2 ring-blood ring-inset" : ""}`}
            onClick={(event) => onCell(x, y, event)}
            onPointerEnter={(event) => {
              if (occupant) onHover({ nation: occupant, x: event.clientX, y: event.clientY });
            }}
            onPointerMove={(event) => {
              if (occupant) onHover({ nation: occupant, x: event.clientX, y: event.clientY });
            }}
            onPointerLeave={() => onHover(null)}
          >
            {occupant && <Token nation={occupant} reveal={reveal} />}
          </button>
        );
      })}
    </div>
  );
}

function Token({ nation, reveal }: { nation: Nation; reveal: boolean }) {
  if (!nation.alive) {
    return (
      <span className="flex flex-col items-center">
        <span className="block h-4 w-5 rounded-t-lg rounded-b-sm bg-surface-2" />
        {reveal && <span className="mt-0.5 text-xs leading-none text-muted">0·{nation.ap}</span>}
      </span>
    );
  }
  return (
    <span className="relative flex flex-col items-center">
      <Flag iso={nation.iso} className="h-6 w-8 rounded-sm" />
      {reveal && (
        <span className="mt-0.5 rounded bg-bg px-1 text-xs leading-none text-fg">
          {nation.hp}·{nation.ap}
        </span>
      )}
    </span>
  );
}

function HoverCard({ nation, x, y, reveal }: Hover & { reveal: boolean }) {
  const left = typeof window === "undefined" ? x : Math.max(8, Math.min(x + 14, window.innerWidth - 188));
  const top = typeof window === "undefined" ? y : Math.max(8, Math.min(y + 14, window.innerHeight - 132));
  return (
    <div
      className="pointer-events-none fixed z-30 w-44 rounded-lg border border-line bg-surface p-2"
      style={{ left, top }}
    >
      <Flag iso={nation.iso} className="mb-2 h-8 w-12 rounded-sm" />
      <div className="text-sm font-medium leading-tight">{nation.name}</div>
      <div className="text-sm text-muted">{nation.country}</div>
      {reveal && (
        <div className="mt-1 text-sm">
          {nation.hp} health · {nation.ap} AP · reach {nation.reach}
        </div>
      )}
    </div>
  );
}

function Analyse({
  game,
  cursor,
  onCursor,
  onHome,
}: {
  game: Game;
  cursor: number;
  onCursor: (cursor: number) => void;
  onHome: () => void;
}) {
  const last = game.plies.length - 1;
  const safe = Math.max(0, Math.min(cursor, last));
  const ply = game.plies[safe]!;
  const [hover, setHover] = useState<Hover | null>(null);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === "ArrowLeft") onCursor(Math.max(0, safe - 1));
      if (event.key === "ArrowRight") onCursor(Math.min(last, safe + 1));
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [last, onCursor, safe]);

  return (
    <div className="flex h-dvh flex-col">
      <header className="flex items-center gap-2 border-b border-line px-3 py-2">
        <button type="button" className="min-w-0 flex-1 text-left" onClick={onHome}>
          <span className="block font-display text-2xl leading-none">Record</span>
          <span className="block truncate text-xs text-muted">{victoryLine(game) ?? game.title}</span>
        </button>
        <button type="button" className={btn()} onClick={() => downloadRecord(game)}>
          Download
        </button>
      </header>
      <div className="min-h-0 flex-1 overflow-auto p-2">
        <Board
          nations={ply.snapshot}
          selectedId={null}
          sendMode={false}
          reveal
          onCell={(x, y, point) => {
            const occupant = ply.snapshot.find((nation) => nation.x === x && nation.y === y);
            setHover(occupant ? { nation: occupant, x: point.clientX, y: point.clientY } : null);
          }}
          onHover={setHover}
        />
        <p className="mx-auto mt-3 max-w-3xl text-xs text-muted">Health · AP on each flag. Hover for reach.</p>
      </div>
      <footer className="border-t border-line px-3 py-2">
        <div className="mx-auto flex max-w-3xl flex-col gap-2">
          <div className="flex items-center gap-1">
            <button type="button" className={`${btn()} w-11 px-0`} aria-label="Opening" onClick={() => onCursor(0)}>
              <ChevronsLeft className="size-4" />
            </button>
            <button
              type="button"
              className={`${btn()} w-11 px-0`}
              aria-label="Previous action"
              onClick={() => onCursor(Math.max(0, safe - 1))}
            >
              <ChevronLeft className="size-4" />
            </button>
            <span className="min-w-14 text-center text-sm">
              {safe} / {last}
            </span>
            <button
              type="button"
              className={`${btn()} w-11 px-0`}
              aria-label="Next action"
              onClick={() => onCursor(Math.min(last, safe + 1))}
            >
              <ChevronRight className="size-4" />
            </button>
            <button type="button" className={`${btn()} w-11 px-0`} aria-label="Latest" onClick={() => onCursor(last)}>
              <ChevronsRight className="size-4" />
            </button>
            <label className="sr-only" htmlFor="ply">
              Action
            </label>
            <input
              id="ply"
              className="min-w-0 flex-1"
              type="range"
              min={0}
              max={last}
              value={safe}
              onChange={(event) => onCursor(Number(event.target.value))}
            />
          </div>
          <p className="text-sm">
            Hour {ply.hour}. {ply.text}
          </p>
        </div>
      </footer>
      {hover && <HoverCard nation={hover.nation} x={hover.x} y={hover.y} reveal />}
    </div>
  );
}

function Archive({
  games,
  onOpen,
  onHome,
  onImport,
}: {
  games: Game[];
  onOpen: (game: Game) => void;
  onHome: () => void;
  onImport: (game: Game) => void;
}) {
  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col px-5 py-8">
      <button type="button" className={`${btn("quiet")} self-start px-0`} onClick={onHome}>
        Back
      </button>
      <h1 className="font-display text-4xl">Records</h1>
      <label className={`${btn()} mt-4`}>
        Open a record
        <input
          type="file"
          accept="application/json"
          className="sr-only"
          onChange={async (event) => {
            const file = event.target.files?.[0];
            event.target.value = "";
            if (!file) return;
            try {
              const parsed: unknown = JSON.parse(await file.text());
              if (!isGame(parsed)) {
                toast.error("That record could not be read.");
                return;
              }
              onImport(parsed);
            } catch {
              toast.error("That record could not be read.");
            }
          }}
        />
      </label>
      {games.length === 0 ? (
        <p className="mt-6 text-sm text-muted">Finished tables are kept here, ready to step through.</p>
      ) : (
        <ul className="mt-4 flex flex-col gap-2">
          {games.map((game) => (
            <li key={game.id}>
              <button type="button" className="w-full rounded-lg border border-line bg-surface px-3 py-3 text-left" onClick={() => onOpen(game)}>
                <span className="block text-sm font-medium">{victoryLine(game)}</span>
                <span className="mt-1 block text-xs text-muted">
                  {game.title} · {Math.max(0, game.plies.length - 1)} actions
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}

function Codex({ cloud, onHome }: { cloud: boolean | null; onHome: () => void }) {
  const rules = [
    "March to a neighboring land square for 1 AP. The sea, nations, and gravestones block the step.",
    "Strike a nation inside your reach for 1 AP. The third blow eliminates them. Lives are never shown.",
    "Extend reach for 2 AP. Send 1 AP to a nation inside your reach. Abdicate to leave the map.",
    "Sound the bell to advance the hour. Living nations gain 2 AP.",
    "The chronicle names only the blow that ends a nation.",
    "When one nation remains, they rule the world. The record can be analysed with health, AP, and reach visible.",
    "Confirm asks before an action. Abdication, sending AP, and the bell always ask.",
  ];
  return (
    <main className="mx-auto flex min-h-dvh max-w-md flex-col px-5 py-8">
      <button type="button" className={`${btn("quiet")} self-start px-0`} onClick={onHome}>
        Back
      </button>
      <h1 className="font-display text-4xl">Codex</h1>
      <ul className="mt-4 flex flex-col gap-3">
        {rules.map((rule) => (
          <li key={rule} className="text-sm text-fg">
            {rule}
          </li>
        ))}
      </ul>
      <p className="mt-6 text-sm text-muted">
        {cloud
          ? "Shared tables are connected. Health and action points stay off the public board."
          : "This table stays on this device. Shared rooms open once Supabase is connected."}
      </p>
    </main>
  );
}

function ConfirmDialog({ pending, onCancel }: { pending: Pending | null; onCancel: () => void }) {
  return (
    <AlertDialog.Root open={pending !== null} onOpenChange={(open) => !open && onCancel()}>
      <AlertDialog.Portal>
        <AlertDialog.Overlay className="fixed inset-0 z-40 bg-bg/70" />
        <AlertDialog.Content
          className="fixed inset-x-4 top-1/2 z-50 mx-auto max-w-sm -translate-y-1/2 rounded-lg border border-line bg-surface p-4"
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              pending?.run();
            }
          }}
        >
          <AlertDialog.Title className="font-display text-3xl leading-tight">{pending?.title}</AlertDialog.Title>
          <AlertDialog.Description className="mt-1 text-sm text-muted">{pending?.detail}</AlertDialog.Description>
          <div className="mt-4 flex justify-end gap-2">
            <AlertDialog.Cancel className={btn()}>Cancel</AlertDialog.Cancel>
            <AlertDialog.Action className={btn("solid")} onClick={() => pending?.run()}>
              Confirm
            </AlertDialog.Action>
          </div>
        </AlertDialog.Content>
      </AlertDialog.Portal>
    </AlertDialog.Root>
  );
}

function downloadRecord(game: Game) {
  const blob = new Blob([JSON.stringify(game, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  const slug = game.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
  link.download = `${slug || "alliance"}-record.json`;
  link.click();
  URL.revokeObjectURL(url);
}
