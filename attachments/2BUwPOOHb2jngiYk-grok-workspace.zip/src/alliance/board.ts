export const WIDTH = 8;
export const HEIGHT = 6;

const ROWS = ["LLLLLLLL", "LLLLLLLL", "LLLSSLLL", "LLLSSLLL", "LLLLLLLL", "LLLLLLLL"];

export function isLand(x: number, y: number): boolean {
  if (x < 0 || y < 0 || x >= WIDTH || y >= HEIGHT) return false;
  return ROWS[y]![x] === "L";
}

export function landCells(): { x: number; y: number }[] {
  const cells: { x: number; y: number }[] = [];
  for (let y = 0; y < HEIGHT; y += 1) {
    for (let x = 0; x < WIDTH; x += 1) {
      if (isLand(x, y)) cells.push({ x, y });
    }
  }
  return cells;
}
