-- Project: Alliance
-- Run once in the Supabase SQL editor.
-- Hidden stats (health, action points, reach, the full record) live in
-- private.table_state and are not granted to the browser.
-- The server uses SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY only.

create schema if not exists private;

create table if not exists public.tables (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  status text not null default 'live' check (status in ('live', 'ended')),
  hour integer not null default 1 check (hour > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.seats_public (
  table_id uuid not null references public.tables (id) on delete cascade,
  seat integer not null check (seat >= 0),
  player_name text not null,
  country text not null,
  iso text not null,
  x integer,
  y integer,
  alive boolean not null default true,
  primary key (table_id, seat)
);

create table if not exists private.table_state (
  table_id uuid primary key references public.tables (id) on delete cascade,
  state jsonb not null
);

alter table public.tables enable row level security;
alter table public.seats_public enable row level security;

grant usage on schema public to anon, authenticated;
grant select on public.tables, public.seats_public to anon, authenticated;
revoke all on schema private from anon, authenticated;
revoke all on private.table_state from anon, authenticated;
